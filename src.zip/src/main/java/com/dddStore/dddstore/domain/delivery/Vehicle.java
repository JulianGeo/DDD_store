package com.dddStore.dddstore.domain.delivery;

import com.dddStore.dddstore.domain.delivery.values.MechCertificate;
import com.dddStore.dddstore.domain.delivery.values.Soat;
import com.dddStore.dddstore.domain.delivery.values.VehicleData;

public class Vehicle {
    private VehicleData vehicleData;
    private Soat soat;
    private MechCertificate mechCertificate;

}
