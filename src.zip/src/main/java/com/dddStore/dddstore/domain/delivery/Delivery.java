package com.dddStore.dddstore.domain.delivery;

public class Delivery {
}
