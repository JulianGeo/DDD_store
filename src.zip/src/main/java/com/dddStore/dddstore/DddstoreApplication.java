package com.dddStore.dddstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DddstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(DddstoreApplication.class, args);
	}

}
