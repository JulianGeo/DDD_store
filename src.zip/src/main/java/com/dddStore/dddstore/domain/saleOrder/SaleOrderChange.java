package com.dddStore.dddstore.domain.saleOrder;

import com.dddStore.dddstore.generic.EventChange;

public class SaleOrderChange extends EventChange {

}
