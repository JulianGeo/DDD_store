package com.dddStore.dddstore.domain.accounting;

public class Accounting {
}
