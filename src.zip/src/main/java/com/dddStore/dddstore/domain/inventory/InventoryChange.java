package com.dddStore.dddstore.domain.inventory;

import com.dddStore.dddstore.generic.EventChange;

public class InventoryChange extends EventChange {

}
